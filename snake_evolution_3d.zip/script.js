
let canvas = document.getElementById("gameCanvas");
let ctx = canvas.getContext("2d");
canvas.width = 400;
canvas.height = 400;

let snake = [{x: 200, y: 200}];
let food = spawnFood();
let direction = "RIGHT";
let running = false;
let interval;
let level = 1;
let score = 0;

document.addEventListener("keydown", changeDirection);
document.getElementById("volumeSlider").addEventListener("input", adjustVolume);

let eatSound = new Audio("eat.mp3");
let gameOverSound = new Audio("gameover.mp3");
let bgMusic = new Audio("bg.mp3");
bgMusic.loop = true;

function startGame() {
    if (!running) {
        running = true;
        bgMusic.play();
        interval = setInterval(updateGame, 100);
    }
}

function pauseGame() {
    running = false;
    clearInterval(interval);
    bgMusic.pause();
}

function restartGame() {
    snake = [{x: 200, y: 200}];
    direction = "RIGHT";
    running = false;
    score = 0;
    level = 1;
    food = spawnFood();
    clearInterval(interval);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    bgMusic.currentTime = 0;
    bgMusic.pause();
}

function updateGame() {
    let head = { ...snake[0] };
    switch(direction) {
        case "LEFT": head.x -= 20; break;
        case "UP": head.y -= 20; break;
        case "RIGHT": head.x += 20; break;
        case "DOWN": head.y += 20; break;
    }

    if (head.x < 0 || head.y < 0 || head.x >= canvas.width || head.y >= canvas.height || snake.some(s => s.x === head.x && s.y === head.y)) {
        gameOverSound.play();
        alert("Game Over! Score: " + score);
        restartGame();
        return;
    }

    snake.unshift(head);

    if (head.x === food.x && head.y === food.y) {
        score++;
        if (score % 5 === 0) level++;
        food = spawnFood();
        eatSound.play();
    } else {
        snake.pop();
    }

    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "lime";
    snake.forEach(part => ctx.fillRect(part.x, part.y, 20, 20));

    ctx.fillStyle = "red";
    ctx.fillRect(food.x, food.y, 20, 20);

    ctx.fillStyle = "#fff";
    ctx.fillText("Level: " + level + " Score: " + score, 10, 10);
}

function spawnFood() {
    return {
        x: Math.floor(Math.random() * 20) * 20,
        y: Math.floor(Math.random() * 20) * 20
    };
}

function changeDirection(e) {
    const key = e.key;
    if (key === "ArrowLeft" && direction !== "RIGHT") direction = "LEFT";
    else if (key === "ArrowUp" && direction !== "DOWN") direction = "UP";
    else if (key === "ArrowRight" && direction !== "LEFT") direction = "RIGHT";
    else if (key === "ArrowDown" && direction !== "UP") direction = "DOWN";
}

function adjustVolume(e) {
    let volume = e.target.value;
    bgMusic.volume = volume;
    eatSound.volume = volume;
    gameOverSound.volume = volume;
}
